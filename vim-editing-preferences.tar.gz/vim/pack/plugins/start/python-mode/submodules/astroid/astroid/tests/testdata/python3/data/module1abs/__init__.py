
from . import core
from .core import *
print(sys.version)
