<!DOCTYPE html>
<html>
    <body>
        <?php
            print "<p>Hello, World!</p>";
        ?>
    </body>
</html>
