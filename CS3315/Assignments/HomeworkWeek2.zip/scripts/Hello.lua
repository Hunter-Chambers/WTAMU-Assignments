print ("Hello, World!")
