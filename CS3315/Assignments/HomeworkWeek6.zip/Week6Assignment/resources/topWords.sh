#!/usr/bin/env bash

# this is an if statement that will display a usage message
# if the user did not specify enough arguments on the command line
if [ $# -lt 3 ]; then
    printf "Not enough args provided. Need 3.\n"
    printf "USAGE:\n"
    printf "\ttopWords.sh <file with websites> <file with stopwords> "
    printf "<num of words to display>"
    exit 1
fi

websites="$1"             # path to file with list of websites to read from
IFS= read -r regex < "$2" # $regex is now the line from the stop words file

while IFS= read -r site            # this is a while loop that will read each line
do                                 # from websites and store it into $site

    printf "$site top $3 words:\n" # display the website we are visiting
                                   # and how many top words to display

    curl -s "$site" |              # pull source code
    tr '[:upper:]' '[:lower:]' |   # translate the code to all lowercase
    grep -oE "[[:lower:]']+" |     # match all possible words
    grep -vE "$regex" |            # remove the words that are defined as stop words
    sort |                         # sort the list of words
    uniq -c |                      # remove duplicates and prefix each with how
                                   # many times they appeared
    sort -nr |                     # sort again, in reverse
    head -n $3                     # display the top words

    printf "\n"
done < "$websites"
