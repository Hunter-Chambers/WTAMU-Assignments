#!/usr/bin/env bash

# this is an if statement that will display a usage message
# if the user did not specify enough arguments on the command line
if [ $# -lt 2 ]; then
    printf "Not enough args provided. Need 2.\n"
    printf "USAGE:\n"
    printf "\tfindRegex.sh </path/to/file-with-websites> <regex>\n"
    exit 1
fi

websites="$1"   # path to file with list of websites to read from
i=1             # variable to differentiate output file names

while IFS= read -r site # this is a while loop that will read each line
do                      # from websites and store it into $site

    # display the website that is being checked
    printf "Checking for (?s)$2 in\n$site\n"

    # pull source code
    (curl -s "$site" |

    # find all the matches to the specified regex.
    # -z reads the input as a single line so that way we can
    #   find matches that span multiple lines.
    # -P allows grep to use complex regexs like:
    #   (?s)
    #   (?<=)
    # (?s) makes the '.' match any character including newline
    grep -ozP "(?s)$2" |

    # the previous grep command causes there to be some NULL (x00) characters
    # where there should be some newline characters. This sed command replaces
    # those NULL characters with the specified replacement
    sed "s/\x00/\n\n********************\n\n/g") > website-$i.txt # throw the output to a file

    # display where the output went
    printf "Saved to website-$i.txt\n\n"

    # increment i
    let "i += 1"

done < "$websites"
